package com.demo.coins

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity


class CoinsListSpecial: AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.coins_list_special)
    }
}

