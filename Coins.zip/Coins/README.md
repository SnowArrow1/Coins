this app still has some bug and optimization problem
but the required feature is work properly as it should

some coin icon is still loaded with the wrong picture but if you scroll past it and return it will fetch the new picture that should be the right match of the coin name